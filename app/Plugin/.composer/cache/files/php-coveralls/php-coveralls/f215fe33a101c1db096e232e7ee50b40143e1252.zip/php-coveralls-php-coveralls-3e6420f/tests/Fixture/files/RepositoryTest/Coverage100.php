<?php
namespace CoverallsTest;

class Coverage100
{
    public function doSomething()
    {
        $var = '';
    }
}
