<?php
namespace CoverallsTest;

class Coverage90
{
    public function doSomething()
    {
        $var = '';
    }
}
