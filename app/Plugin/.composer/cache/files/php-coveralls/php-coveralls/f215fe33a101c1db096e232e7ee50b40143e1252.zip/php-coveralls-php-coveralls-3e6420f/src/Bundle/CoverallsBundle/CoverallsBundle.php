<?php

namespace PhpCoveralls\Bundle\CoverallsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Coveralls bundle.
 *
 * @author Kitamura Satoshi <with.no.parachute@gmail.com>
 */
class CoverallsBundle extends Bundle
{
}
