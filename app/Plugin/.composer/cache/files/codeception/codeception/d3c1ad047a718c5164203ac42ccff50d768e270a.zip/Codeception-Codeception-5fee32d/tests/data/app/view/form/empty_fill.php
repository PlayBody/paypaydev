<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Test inserting a submit button</title>
</head>
<body>
    <form method="POST" action="/form/emptyFill">
        <input type="text" name="test" value="" />
    </form>
</body>
</html>