<?php
class SampleTest extends \PHPUnit\Framework\TestCase
{
    public function testOfTest() {
        $this->assertTrue(true);
    }
    
}