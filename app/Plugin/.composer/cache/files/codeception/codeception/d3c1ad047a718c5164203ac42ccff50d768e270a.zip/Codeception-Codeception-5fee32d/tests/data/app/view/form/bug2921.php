<!DOCTYPE html>
<html>
<head>
</head>
<body>
<textarea id="ta" name="foo" rows="3">bar baz
</textarea>
</body>
</html>