<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome!</title>
</head>
<body>
    <form method="get" action="/form/example5">
        <input type="text" name="username">
        <input type="text" name="password">
        <button type="submit" value="Submit">Login</button>
    </form>
</body>
</html>
