<html>
<head>
</head>
<body>
<form id="foo" method="POST" action="/form/example17">
<input type="text" value="baz" name="FooBar[bar]">
<input type="text" value="mmhm" name="Food[beer][yum][yeah]">
</form>
</body>
</html>