<html>
<body>

<div class="link">Not Clickable</div>
<a href="/info" class="link">Clickable</a>

<div>Press Me!</div>
<a href="/info">Press Me!</a>
</body>
</html>