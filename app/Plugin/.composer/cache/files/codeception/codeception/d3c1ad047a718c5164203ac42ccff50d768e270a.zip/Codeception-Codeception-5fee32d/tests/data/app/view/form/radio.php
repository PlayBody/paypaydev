<html>
<body>
<form action="/form/radio" method="POST">
    <input type="radio" id="agree" name="terms" value="agree" />
    <label for="disagree">Get Off</label>
    <input type="radio" id="disagree" name="terms" value="disagree" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>