<?php
namespace Codeception\Exception;

class Incomplete extends \PHPUnit\Framework\IncompleteTestError
{

}
