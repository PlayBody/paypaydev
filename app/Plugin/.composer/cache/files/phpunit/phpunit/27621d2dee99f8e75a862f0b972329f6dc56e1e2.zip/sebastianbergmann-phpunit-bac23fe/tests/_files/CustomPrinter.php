<?php
use PHPUnit\TextUI\ResultPrinter;

class CustomPrinter extends ResultPrinter
{
}
