<?php
use PHPUnit\Framework\TestCase;

class OneTestCase extends TestCase
{
    public function noTestCase()
    {
    }

    public function testCase($arg = '')
    {
    }
}
