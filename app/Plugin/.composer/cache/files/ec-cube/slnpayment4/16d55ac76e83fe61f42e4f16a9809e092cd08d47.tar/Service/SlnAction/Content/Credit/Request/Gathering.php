<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Credit\Request;

class Gathering extends Auth
{
    
}