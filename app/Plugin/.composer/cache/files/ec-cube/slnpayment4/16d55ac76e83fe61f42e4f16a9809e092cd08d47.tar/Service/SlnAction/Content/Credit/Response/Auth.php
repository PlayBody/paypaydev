<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Credit\Response;

class Auth extends Check
{
    
}