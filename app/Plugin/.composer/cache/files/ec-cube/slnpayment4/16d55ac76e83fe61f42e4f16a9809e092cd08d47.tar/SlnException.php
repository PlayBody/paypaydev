<?php

namespace Plugin\SlnPayment4;

class SlnException extends \Exception
{
}