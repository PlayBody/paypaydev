<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Receipt\Response;

class Del extends Chg
{
    
}