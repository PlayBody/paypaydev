<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Member\Response;

class MemRefM extends MemRef
{
}