<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Member\Request;

class MemRef extends MemInval
{
}