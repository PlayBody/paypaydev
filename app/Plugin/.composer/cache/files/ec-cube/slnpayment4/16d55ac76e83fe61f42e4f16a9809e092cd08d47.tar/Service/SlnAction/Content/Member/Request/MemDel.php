<?php

namespace Plugin\SlnPayment4\Service\SlnAction\Content\Member\Request;

class MemDel extends MemInval
{
}